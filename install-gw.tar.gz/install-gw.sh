#!/bin/sh

# -- персональные настройки
MAIN_LAN_PREF='192.168.150'
MAIN_LAN=$MAIN_LAN_PREF'.0\/24'
MAIN_MASK='255.255.255.0'
MAIN_GW_ADDR=$MAIN_LAN_PREF'.222'

MAIN_GW_NAME='gw-bsd12'
MAIN_DOMAIN='local'
MAIN_WPAD='wpad'
MAIN_NS='ns'

# -- обязательно заменить!
MAIN_MAIL='dev@null'
MAIN_MAILER='localhost'

MAIN_PC=$MAIN_LAN_PREF'.105'

MAIN_EXTIF='SYNCDHCP'
#MAIN_EXTIF='inet x.x.x.x netmask y.y.y.y'


# -- Версии пакетов
APACHE_VER=24
PHP_VER=73
PSQL_VER=95		# 9.5 потому что php7.3 по дефолту его поддерживает. лень править
DHCP_VER=44
MPD_VER=5

#-- Пути
GW_CONF=gw-conf


# -- перенаправление почты для пользователей (в основном для root)
# -- почта отправляется на локальный сервер по MX, поэтому sendmail не настраивается

if grep -q "root:${MAIN_MAIL}" /etc/aliases
 then
  echo "alias found. skip."
else
 echo "root:${MAIN_MAIL}" >> /etc/aliases
 newaliases
fi

# -- Установка необходимых пакетов (можно в одну строку было, но мне так удобнее :))
pkg install -y mc 

pkg install -y isc-dhcp$DHCP_VER-server
pkg install -y igmpproxy
pkg install -y mpd$MPD_VER

pkg install -y apache$APACHE_VER
pkg install -y postgresql$PSQL_VER-server
pkg install -y privoxy
pkg install -y squid

pkg install -y php$PHP_VER
pkg install -y php$PHP_VER-opcache
pkg install -y php$PHP_VER-session
pkg install -y php$PHP_VER-bz2
pkg install -y php$PHP_VER-ctype
pkg install -y php$PHP_VER-dom
pkg install -y php$PHP_VER-filter
pkg install -y php$PHP_VER-hash
pkg install -y php$PHP_VER-iconv
pkg install -y php$PHP_VER-json
pkg install -y php$PHP_VER-pdo
pkg install -y php$PHP_VER-pgsql
pkg install -y php$PHP_VER-posix
pkg install -y php$PHP_VER-simplexml
pkg install -y php$PHP_VER-sqlite3
pkg install -y php$PHP_VER-tokenizer
pkg install -y php$PHP_VER-xml
pkg install -y php$PHP_VER-xmlwriter
pkg install -y php$PHP_VER-pdo_sqlite
pkg install -y php$PHP_VER-phar
pkg install -y php$PHP_VER-xmlreader
pkg install -y mod_php$PHP_VER

# -- модификация конфигов перед копированием

# 1. rc.conf
sed -i.bak 's/%MAIN_GW_NAME%/'$MAIN_GW_NAME'/g' $GW_CONF/etc/rc.conf
sed -i.bak 's/%MAIN_GW_ADDR%/'$MAIN_GW_ADDR'/g' $GW_CONF/etc/rc.conf
sed -i.bak 's/%MAIN_MASK%/'$MAIN_MASK'/g' $GW_CONF/etc/rc.conf
sed -i.bak 's/%MAIN_EXTIF%/'$MAIN_EXTIF'/g' $GW_CONF/etc/rc.conf
rm $GW_CONF/etc/rc.conf.bak

# 2. pf.conf
sed -i.bak 's/%MAIN_LAN%/'$MAIN_LAN'/g' $GW_CONF/etc/pf.conf
sed -i.bak 's/%MAIN_LAN_PREF%/'$MAIN_LAN_PREF'/g' $GW_CONF/etc/pf.conf
rm $GW_CONF/etc/pf.conf.bak

# 3. unbound
sed -i.bak 's/%MAIN_DOMAIN%/'$MAIN_DOMAIN'/g' $GW_CONF/var/unbound/conf.d/local.conf
sed -i.bak 's/%MAIN_GW_NAME%/'$MAIN_GW_NAME'/g' $GW_CONF/var/unbound/conf.d/local.conf
sed -i.bak 's/%MAIN_GW_ADDR%/'$MAIN_GW_ADDR'/g' $GW_CONF/var/unbound/conf.d/local.conf
sed -i.bak 's/%MAIN_NS%/'$MAIN_NS'/g' $GW_CONF/var/unbound/conf.d/local.conf
sed -i.bak 's/%MAIN_WPAD%/'$MAIN_WPAD'/g' $GW_CONF/var/unbound/conf.d/local.conf
rm $GW_CONF/var/unbound/conf.d/local.conf.bak

sed -i.bak 's/%MAIN_GW_ADDR%/'$MAIN_GW_ADDR'/g' $GW_CONF/var/unbound/unbound.conf
sed -i.bak 's/%MAIN_LAN%/'$MAIN_LAN'/g' $GW_CONF/var/unbound/unbound.conf
rm $GW_CONF/var/unbound/unbound.conf.bak

# -- create unbound configs
/etc/rc.d/local_unbound onesetup


# 4. dhcpd
sed -i.bak 's/%MAIN_LAN_PREF%/'$MAIN_LAN_PREF'/g' $GW_CONF/usr/local/etc/dhcpd.conf
sed -i.bak 's/%MAIN_MASK%/'$MAIN_MASK'/g' $GW_CONF/usr/local/etc/dhcpd.conf
sed -i.bak 's/%MAIN_DOMAIN%/'$MAIN_DOMAIN'/g' $GW_CONF/usr/local/etc/dhcpd.conf
sed -i.bak 's/%MAIN_WPAD%/'$MAIN_WPAD'/g' $GW_CONF/usr/local/etc/dhcpd.conf
sed -i.bak 's/%MAIN_NS%/'$MAIN_NS'/g' $GW_CONF/usr/local/etc/dhcpd.conf
sed -i.bak 's/%MAIN_GW_NAME%/'$MAIN_GW_NAME'/g' $GW_CONF/usr/local/etc/dhcpd.conf
rm $GW_CONF/usr/local/etc/dhcpd.conf.bak

# 5. igmproxy
sed -i.bak 's/%MAIN_LAN%/'$MAIN_LAN'/g' $GW_CONF/usr/local/etc/igmpproxy.conf
rm $GW_CONF/usr/local/etc/igmpproxy.conf.bak

echo 'ip_mroute_load="YES"'>>/boot/loader.conf

# 6. privoxy
sed -i.bak 's/%MAIN_MAIL%/'$MAIN_MAIL'/g' $GW_CONF/usr/local/etc/privoxy/config
rm $GW_CONF/usr/local/etc/privoxy/config.bak

# 7. mpd
sed -i.bak 's/%MAIN_WPAD%/'$MAIN_WPAD'/g' $GW_CONF/usr/local/etc/mpd$MPD_VER/mpd.conf
sed -i.bak 's/%MAIN_DOMAIN%/'$MAIN_DOMAIN'/g' $GW_CONF/usr/local/etc/mpd$MPD_VER/mpd.conf
sed -i.bak 's/%MAIN_LAN_PREF%/'$MAIN_LAN_PREF'/g' $GW_CONF/usr/local/etc/mpd$MPD_VER/mpd.conf
rm $GW_CONF/usr/local/etc/mpd$MPD_VER/mpd.conf.bak

# 8. apache
sed -i.bak 's/%MAIN_MAIL%/'$MAIN_MAIL'/g' $GW_CONF/usr/local/etc/apache$APACHE_VER/httpd.conf
sed -i.bak 's/%MAIN_GW_NAME%/'$MAIN_GW_NAME'/g' $GW_CONF/usr/local/etc/apache$APACHE_VER/httpd.conf
sed -i.bak 's/%MAIN_GW_ADDR%/'$MAIN_GW_ADDR'/g' $GW_CONF/usr/local/etc/apache$APACHE_VER/httpd.conf
rm $GW_CONF/usr/local/etc/apache$APACHE_VER/httpd.conf.bak

# 9. squid
sed -i.bak 's/%MAIN_GW_NAME%/'$MAIN_GW_NAME'/g' $GW_CONF/usr/local/etc/squid/squid.conf
sed -i.bak 's/%MAIN_LAN%/'$MAIN_LAN'/g' $GW_CONF/usr/local/etc/squid/squid.conf
sed -i.bak 's/%MAIN_GW_ADDR%/'$MAIN_GW_ADDR'/g' $GW_CONF/usr/local/etc/squid/squid.conf
rm $GW_CONF/usr/local/etc/squid/squid.conf.bak

# 10. wpad script
sed -i.bak 's/%MAIN_GW_ADDR%/'$MAIN_GW_ADDR'/g' $GW_CONF/usr/local/www/wpad/wpad.dat
rm $GW_CONF/usr/local/www/wpad/wpad.dat.bak

# 11. first_run script
sed -i.bak 's/%MAIN_GW_ADDR%/'$MAIN_GW_ADDR'/g' $GW_CONF/var/first_run.sh
sed -i.bak 's/%MAIN_PC%/'$MAIN_PC'/g' $GW_CONF/var/first_run.sh
rm $GW_CONF/var/first_run.sh.bak

# 12. php script
sed -i.bak 's/%MAIN_MAIL%/'$MAIN_MAIL'/g' $GW_CONF/usr/local/scripts/sql.inc.php
sed -i.bak 's/%MAIN_MAILER%/'$MAIN_MAILER'/g' $GW_CONF/usr/local/scripts/sql.inc.php
rm $GW_CONF/usr/local/scripts/sql.inc.php.bak

# 13. mc Syntax hl for conf files
sed -i.bak 's/(properties|config)/(properties|config|conf)/g' /usr/local/share/mc/syntax/Syntax

# -- завершение
# -- права на файл pf 
if grep -q "root:squid" /etc/devfs.conf
 then
  echo "alias found. skip."
else
 echo "own pf root:squid" >> /etc/devfs.conf
 echo "perm pf 0640" >> /etc/devfs.conf
fi

# -- sysctl tuning
echo '# ====== [ tuning ] ==========' >> /etc/sysctl.conf
echo 'kern.ipc.somaxconn=1024' >> /etc/sysctl.conf
echo 'kern.ipc.nmbclusters=4073888' >> /etc/sysctl.conf
echo 'net.inet.tcp.tso=0' >> /etc/sysctl.conf
echo 'net.inet.tcp.mssdflt=1460' >> /etc/sysctl.conf
echo 'net.inet.tcp.minmss=1300' >> /etc/sysctl.conf
echo 'net.inet.ip.forwarding=1' >> /etc/sysctl.conf

echo '#'
echo '# General Security and DoS mitigation'
echo '#'

echo 'net.inet.ip.check_interface=1		# verify packet arrives on correct interface (default 0)' >> /etc/systl.conf
echo 'net.inet.ip.process_options=0		# ignore IP options in the incoming packets (default 1)' >> /etc/sysctl.conf
echo 'net.inet.ip.random_id=1			# assign a random IP_ID to each packet leaving the system (default 0)' >> /etc/sysctl.conf
echo 'net.inet.ip.redirect=0			# do not send IP redirects (default 1)' >> /etc/sysctl.conf
echo 'net.inet.icmp.drop_redirect=1		# no redirected ICMP packets (default 0)' >> /etc/sysctl.conf
echo 'net.inet.tcp.always_keepalive=0		# disable tcp keep alive detection for dead peers, can be spoofed (default 1)' >> /etc/sysctl.conf
echo 'net.inet.tcp.drop_synfin=1		# SYN/FIN packets get dropped on initial connection (default 0)' >> /etc/sysctl.conf
echo 'net.inet.tcp.fast_finwait2_recycle=1	# recycle FIN/WAIT states quickly (helps against DoS, but may cause false RST) (default 0)' >> /etc/sysctl.conf
echo 'net.inet.tcp.msl=5000			# Maximum Segment Lifetime is the time a TCP segment can exist on the network and is ...' >> /etc/sysctl.conf
echo 'net.inet.tcp.path_mtu_discovery=0		# disable MTU discovery since most ICMP type 3 packets are dropped by others (default 1)' >> /etc/sysctl.conf
echo 'net.inet.udp.blackhole=1			# drop udp packets destined for closed sockets (default 0)' >> /etc/sysctl.conf
echo 'net.inet.tcp.blackhole=2			# drop tcp packets destined for closed ports (default 0)' >> /etc/sysctl.conf
echo 'security.bsd.see_other_uids=0		# users only see their own processes. root can see all (default 1)' >> /etc/sysctl.conf

echo '
#net.bpf.optimize_writers=0           # bpf are write-only unless program explicitly specifies the read filter (default 0)
#net.bpf.zerocopy_enable=0            # zero-copy BPF buffers, breaks dhcpd ! (default 0)
#net.inet.ip.portrange.randomized=1   # randomize outgoing upper ports (default 1)
#net.inet.ip.accept_sourceroute=0     # drop source routed packets since they can not be trusted (default 0)
#net.inet.ip.sourceroute=0            # if source routed packets are accepted the route data is ignored (default 0)
#net.inet.ip.stealth=1                # do not reduce the TTL by one(1) when a packets goes through the firewall (default 0)
#net.inet.icmp.bmcastecho=0           # do not respond to ICMP packets sent to IP broadcast addresses (default 0)
#net.inet.icmp.maskfake=0             # do not fake reply to ICMP Address Mask Request packets (default 0)
#net.inet.icmp.maskrepl=0             # replies are not sent for ICMP address mask requests (default 0)
#net.inet.icmp.log_redirect=0         # do not log redirected ICMP packet attempts (default 0)
#net.inet.icmp.icmplim=200            # number of ICMP/TCP RST packets/sec, increase for bittorrent or many clients. (default 200)
#net.inet.icmp.icmplim_output=1       # show "Limiting open port RST response" messages (default 1)
#net.inet.tcp.ecn.enable=0            # explicit congestion notification (ecn) warning: some ISP routers abuse ECN (default 0)
#net.inet.tcp.maxtcptw=50000          # max number of tcp time_wait states for closing connections (default ~27767)
#net.inet.tcp.rfc3042=1               # on packet loss trigger the fast retransmit algorithm instead of tcp timeout (default 1)
#net.route.netisr_maxqlen=256         # route queue length (rtsock using "netstat -Q") (default 256)
#vfs.zfs.min_auto_ashift=12            # ZFS 4k alignment
' >> /etc/sysctl.conf
echo '# ====== [ end tuning ] ==========' >> /etc/syslog.ctl

# -- newslog
echo '/var/log/mpd.log 600 7 * @T00 J' >> /etc/newsyslog.conf
echo '/var/log/dhcpd.log 644 7 * @T00 JC' >> /etc/newsyslog.conf
echo '/var/log/pflog 600 3 100 * JB /var/run/pflogd.pid'>> /etc/newsyslog.conf

# -- logs
touch /var/log/console.log
touch /var/log/mpd.log
touch /var/log/pflog.txt
touch /var/log/dhcpd.log

# -- для логов апача отдельная папка
mkdir /var/log/apache

# -- 
mkdir -p /usr/local/var/squid/saved
mkdir -p /usr/local/var/pflog

# -- ports init
#portsnap fetch
#portsnap extract

# -- копирование конфигов
cp -R $GW_CONF/* /

