#!/bin/sh

pfctl=/sbin/pfctl

### pf ###
$pfctl -a "vpn-rdr" -F all
$pfctl -a "vpn-rul" -F all
######

return 0
