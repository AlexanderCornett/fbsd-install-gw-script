#!/bin/sh

if=$1

pfctl=/sbin/pfctl

### pf ###
echo "rdr pass on $if inet proto tcp from any to any port 80 -> 127.0.0.1 port 3128" | $pfctl -a "vpn-rdr" -f -
echo "pass quick on $if" | $pfctl -a "vpn-rul" -f -
######

return 0
