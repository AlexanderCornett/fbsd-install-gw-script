<?php
//require("C:\\WinApp\\Scripts\\sql.inc.php");
include("/usr/local/scripts/sql.inc.php");
include("/usr/local/scripts/mail.inc.php");

ini_set('SMTP',postserv);

$subject = 'Mon top squid list';

$d = getdate();
$d1 = mktime(0,0,0,$d['mon']-1,1,$d['year']);
$d2 = mktime(0,0,0,$d['mon'],$d['mday']-1,$d['year']);

//$d1 = mktime(0,0,0,3,1,2007);
//$d2 = mktime(0,0,0,3,31,2007);

$dt1 = date("m.d.Y",$d1);
$dt2 = date("m.d.Y",$d2);


$message = "<html><head><meta http-equiv='Content-Type' content='text/html; charset=utf-8'></head>";
$message .= '<body><p>Top info between '.date("d.m.Y",$d1).'-'.date("d.m.Y",$d2)."</p>";


// open a connection to the database server
$constr = "host=".SQLHost." dbname=".database." user=".SQLUser." password=".SQLPass;
$connection = pg_connect($constr);

if (!$connection)
{
    die("Could not open connection to database server");
}


//////////////////////////////////////////////////////////////////////////////////////////
$message.= '<p>Top site:'. "</p>";

$sql = "select spTopSite('".$dt1." 00:00:00.000', '".$dt2." 23:59:59.999')";
$sql = $sql.'; fetch 30 from "<unnamed portal 1>";';

$message.= '<table border=1>';
$message.= '<tr bgcolor="gray">';
$message.= '<td>Link</td>';
$message.= '<td>Traffic (b)</td>';
$message.= '</tr>';

$res = pg_query($sql);
while($row=pg_fetch_row($res))
{
    $message.= '<tr>';
    $message.= '<td>http://'.$row[1].'</td>';
    $message.= '<td align="right">'.number_format($row[0],0,',',' ').'</td>';
    $message.= '</tr>';
};
$message.= '</table>';


//////////////////////////////////////////////////////////////////////////////////////////
$message.= '<p>Top users:'. "</p>";

$sql = "select spTopUser( '".$dt1." 00:00:00.000', '".$dt2." 23:59:59.999')";
$sql = $sql.'; fetch 30 from "<unnamed portal 2>";';

$message.= '<table border=1>';
$message.= '<tr bgcolor="gray">';
$message.= '<td>User</td>';
$message.= '<td>Traffic (b)</td>';
$message.= '</tr>';

#$user=0;
#$uname=0;

$i=0;
$res = pg_query($sql);

while($row=pg_fetch_row($res))
{
  $uname[$i]=GetIdentName($row[0]);

  $message.= '<tr>';
  $message.= '<td>'.gethostbyaddr($uname[$i]).'</td>';
  $message.= '<td align="right">'.number_format($row[1],0,'.',' ').'</td>';
  $message.= '</tr>';

  $user[$i]=trim($row[0]);
  $i++;
};
$message.= '</table>';

if ($i==0)
{
 pg_close($connection);
 echo "No data\n";
 exit;
}


//////////////////////////////////////////////////////////////////////////////////////////
$message.= '<p>Top users top sites:'. "</p>";

$message.= '<table border=1>';

for ($i=0;$i<count($user);$i++)
{

  $message.= '<tr bgcolor="gray">';
  $message.= '<td>'.gethostbyaddr($uname[$i]).'</td>';
  $message.= '<td>Traffic (b)</td>';
  $message.= '</tr>';

  $j=$i+3;

  $sql="select spTopUserSite('".$dt1." 00:00:00.000', '".$dt2." 23:59:59.999', '".$user[$i]."')";
  $portal = '"'.'<unnamed portal '.$j.'>"';
  $sql=$sql.'; fetch 30 from '.$portal;

  $res = pg_query($sql);
  while($row=pg_fetch_row($res))
  {

    $message.= '<tr>';
    $message.= '<td>http://'.$row[1].'</td>';
    $message.= '<td align="right">'.number_format($row[0],0,'.',' ').'</td>';
    $message.= '</tr>';
  };
};
$message.= '</table>';
$message.= '</body></html>';

pg_close($connection);

//================================================================================================
$h = fopen("/usr/local/scripts/monthreport.html","w");
//fwrite($h,convert_cyr_string($message,"w","k"));
fwrite($h,$message);
fclose($h);

//================================================================================================

$my_file = "monthreport.html";
$my_path = "/usr/local/scripts/";
$my_name = "Squid Server";
$my_mail = mainmail;
$my_replyto = replyto;
$my_subject = "Monthly Squid Report.";
$my_message = "Hallo,\r\nMonthly Squid Report.\r\n\r\ngr. Your Squid";

mail_attachment($my_file, $my_path, mailto, $my_mail, $my_name, $my_replyto, $my_subject, $my_message);

//================================================================================================

///////////////////////////////////////////////////////////////////////////////////////////////////
function GetIdentName($ident)
{
  $result = $ident;

//  $sql = "select username from quotes where ident='".$ident."'";
//  $res = mssql_query($sql);
//  if ($row=mssql_fetch_row($res)) $result=$row[0];

  return $result;

};

?>