#!/bin/sh

#if [ $# -ne 4 ]; then
#  echo Invalid args
#  logger -s -t dhcp-event "Invalid args \"$@\""
#  exit 1 
#fi


PATH=${PATH}:/usr/local/sbin:/usr/local/bin:
export PATH

action=$1
client_ip=$2
client_mac=$3
client_name=$4

file=/var/unbound/conf.d/local.data.conf
bfile=/var/unbound/conf.d/local.data.bkp

# Check whether a domain is used
domain=$(awk '/^domain/ {print $2}' /etc/resolv.conf)

if [ -z $domain ]; then
    client_fqdn_name=$client_name
    client_search_expr="local-data: \"$client_name"
else
    client_fqdn_name=$client_name.$domain
    client_search_expr="local-data: \"$client_name.$domain"
fi

client_rev_ip=`echo $client_ip | awk -F. '{OFS="."; print $4,$3,$2,$1}'`.in-addr.arpa


#echo "====================================================" >> /usr/local/a.txt
#echo "seacrh exr: $client_search_expr" >> /usr/local/a.txt


# Copy original hosts file to a tmp file.
# Will be used later to check if changes were made.
cp $file $bfile

case "$action" in
    commit) # add mapping for new lease
#        echo "- new lease event, setting static mapping for host $client_fqdn_name (MAC=$client_mac, IP=$client_ip)" >> /usr/local/a.txt
#        echo "grep -q  $client_search_expr $file" >> /usr/local/a.txt
        grep -q "$client_search_expr" $file 
        if [ $? == 0 ]; then
#            echo pattern found, removing >> /usr/local/a.txt
	    exit 
#            sed -i "/ $client_search_expr/d" $file  
        else
#            echo pattern NOT found >> /usr/local/a.txt
        fi

        # check if hostname already exists (e.g. a static host mapping)
        # if so don't overwrite (use CTRL-V TAB for tabs)
#        echo "grep -q \( \| \)\+$client_search_expr\(    \| \)\+ $file" >> /usr/local/a.txt
#        grep -q "\( \| \)\+$client_search_expr\(    \| \)\+" $file
#        if [ $? == 0 ]; then
#           echo host $client_fqdn_name already exists, exiting >> /usr/local/a.txt
#           exit 
#        fi

        sh -c "printf 'local-data: \"%-30s\t A %s\"\t#dhcp-event %s\n' $client_fqdn_name $client_ip $client_mac >> $file"
        sh -c "printf 'local-data: \"%-30s\t IN PTR %s\"\t#dhcp-event %s\n' $client_rev_ip $client_fqdn_name $client_mac >> $file"
#        echo Entry was added >> /usr/local/a.txt
    ;;

    release) # delete mapping for released address
#        echo "- lease release event, deleting static mapping for host $client_ip ($client_mac)" >> /usr/local/a.txt
        sed -i .orig "/#dhcp-event $client_mac/d" $file
    ;;


    expiry) # delete mapping for released address
#        echo "- lease expiry event, deleting static mapping for host $client_ip ($client_mac)" >> /usr/local/b.txt
#        echo "sed -i .orig /#dhcp-event $client_mac/d $file" >> /usr/local/b.txt
#        echo "---------------------------------------------" >> /usr/local/b.txt
        /usr/bin/sed -i .orig "/#dhcp-event $client_mac/d" $file
    ;;

    *)
        logger -s -t dhcp-event "Invalid command \"$1\""
        exit 1;
    ;;
esac

# If changes made, flush dnsmasq cache and reload config files
cmp -s $file $bfile

if [ $? -ne 0 ]; then
    echo Changes made. Reloading zone...
    local-unbound-control reload
else
    echo No changes made
fi



