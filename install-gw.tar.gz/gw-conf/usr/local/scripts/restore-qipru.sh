#!/bin/sh

CONF=/var/unbound/conf.d/local-blocking-data.conf

sed -i.bak '/qip.ru/ d' $CONF
rm $CONF.bak
/usr/sbin/unbound-control reload



