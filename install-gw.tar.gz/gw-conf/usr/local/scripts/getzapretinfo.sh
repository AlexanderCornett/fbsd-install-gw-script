#!/bin/sh
#cd /root/zapret-info/zapret-info
#rm -rf z-i
#/usr/local/bin/git clone https://github.com/zapret-info/z-i.git
#cat z-i/dump.csv | sed 1d | cut -f 3 -d ';' > bbb.txt
#| sed 1d | cut -d ';' -f 3 | tr "\|" "\n" | sed 's/^[ \t]*//;s/[ \t]*$//' | uniq > /usr/local/etc/squid/zapret-urls.txt

wget 'http://api.antizapret.info/all.php?type=csv' -O xxx.txt
cat xxx.txt | sed 1d | cut -s -d ';' -f 3 | tr "\|" "\n" | sed 's/^[ \t]*//;s/[ \t]*$//' | sed 's/\[/\\\[/;s/\]/\\\]/' | uniq > zapret-urls.txt