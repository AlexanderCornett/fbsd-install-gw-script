<?php
//define("BasePath","/usr/local/var/traffic_plain/");

define("SQLHost","localhost");
define("SQLUser","pguser");
define("SQLPass","mypass-if-exists");
define("database","corall");

define("squidlogpath","/usr/local/var/squid/");
define("pflogpath","/usr/local/var/pflog/");

define("logfile","/usr/local/var/sq2sql.log");
define("pflogfile","/usr/local/var/pf2sql.log");

define("maillist","%MAIN_MAIL%");
define("postserv","%MAIN_MAILER%");
define("mainmail","%MAIN_MAIL%");
define("replyto","%MAIN_MAIL%");
define("mailto","%MAIN_MAIL%");

?>