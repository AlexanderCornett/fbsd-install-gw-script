<?php
function mail_attachment($filename, $path, $mailto, $from_mail, $from_name, $replyto, $subject, $message) 
{
 $file = $path.$filename;
 $file_size = filesize($file);
 $handle = fopen($file, "r");
 $content = fread($handle, $file_size);
 fclose($handle);

 $content = chunk_split(base64_encode($content));

 $uid = md5(uniqid(time()));
 $name = basename($file);

 // header
 $header  = 	"From: ".$from_name." <".$from_mail.">\r\n";
 $header .= 	"Reply-To: ".$replyto."\r\n";
 $header .= 	"MIME-Version: 1.0\r\n";
 $header .= 	"Content-Type: multipart/mixed; boundary=\"".$uid."\"\r\n";
 $header .= 	"This is a multi-part message in MIME format.\r\n";
 
 // message and attachment
 $eheader = 	"--".$uid."\r\n";
 $eheader .= 	"Content-type:text/plain; charset=iso-8859-1\r\n";
 $eheader .= 	"Content-Transfer-Encoding: 7bit\r\n\r\n";
 $eheader .= 	$message."\r\n\r\n";
 $eheader .= 	"--".$uid."\r\n";
 $eheader .= 	"Content-Type: application/octet-stream; name=\"".$filename."\"\r\n"; // use different content types here
 $eheader .= 	"Content-Transfer-Encoding: base64\r\n";
 $eheader .= 	"Content-Disposition: attachment; filename=\"".$filename."\"\r\n\r\n";
 $eheader .= 	$content."\r\n\r\n";
 
 // finish
 $eheader .= 	"--".$uid."--";


 if (mail($mailto, $subject, $eheader, $header)) 
 {
    echo "mail send ... OK\r\n"; // or use booleans here
 } 
 else 
 {
    echo "mail send ... ERROR!\r\n";
 }
}

?>