#!/bin/sh
PFLOG=/var/log/pflog
FILE=/var/log/pflog5min.$(date "+%Y%m%d%H%M")


if [ -r $PFLOG ] && [ $(stat -f %z $PFLOG) -gt 24 ]; then

    pkill -ALRM -u root -U root -t - -x pflogd

    mv $PFLOG $FILE
    touch $PFLOG
    pkill -HUP -u root -U root -t - -x pflogd
    tcpdump -n -e -s 160 -tttt -r $FILE | logger -t pf -p local0.info
#    tcpdump -n -e  -tttt -r $FILE | logger -t pf -p local0.info
    rm $FILE
fi