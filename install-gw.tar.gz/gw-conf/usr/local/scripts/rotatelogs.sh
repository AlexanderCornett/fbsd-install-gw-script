#!/bin/sh

date=`date -v-1d '+%Y%m%d'`

cp /var/log/squid/access.log /usr/local/var/squid/access.$date
>/var/log/squid/access.log

cp /var/log/pflog.txt /usr/local/var/pflog/pflog.$date
>/var/log/pflog.txt

