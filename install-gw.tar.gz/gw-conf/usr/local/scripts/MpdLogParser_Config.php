<?php

date_default_timezone_set("Asia/Yekaterinburg");

define('LOG_PATH',"/var/log/mpd.log.0.bz2");

$IgnoreIP=array(
//	"1.2.3.4",
//	"5.6.7.8",
);
?>
