#!/usr/local/bin/php

<?php

/*
 *
 * MPD log parser
 * v0.1
 * http://itadept.ru/freebsd-mpd5-server/
 *
 */

error_reporting(E_ALL | E_STRICT );

$time=microtime(true);

/*if (array_key_exists("SendError", $_GET) && $_GET["SendError"]==1)
	SendError("Test topic", "Test error log");*/


define('DAY',86400);
define('HOUR',3600);
define('MINUTE',60);

require '/usr/local/scripts/MpdLogParser_Config.php';

$file=LOG_PATH;

if(count($argv)>1)
	$file=$argv[1];

$parser = new MpdLog($file);
$Connections=0;
$KnownIpCount=0;

while ($item=$parser->read()) {
	if (in_array($item->ip, $IgnoreIP)) {
		$KnownIpCount++;
		continue;
	}

	$ip=str_pad($item->ip, 15, " ", STR_PAD_LEFT);
	$user=str_pad($item->user, 15);
	$rdns=DnsResolver::GetHostName($item->ip);
	if($rdns==$item->ip)
		$rdns='';
	echo "L$item->link$item->direction $item->dateStart $ip ".$item->SesionLenghtString()." $user $rdns $item->ident\r\n";

	$Connections++;
}

echo "Connections: $Connections\r\n";
if($KnownIpCount)
	echo "  +Ignored: $KnownIpCount\r\n";
//$time=round(microtime(true)-$time,3);
//$memory=round(memory_get_usage(true)/1024/1024,3);
//echo date('d.m.Y H:i:s')." Runtime: $time, memory: $memory Mb.";


function ArrValueDef(array $ar, $key, $default=false) {
	if(!array_key_exists($key, $ar))
		return $default;

	return $ar[$key];
}


class MpdLog_Data
{
	//public $line;
    public $ip, $port, $user, $dateStart, $dateEnd, $ident, $tunIP1, $tunIP2, $direction;
	public $link;
	public $identCount;

	function reset() {
		$this->ip=$this->port=$user=$this->dateStart=$this->dateEnd=$this->bytes=$this->ident=$this->tunIP1=$this->tunIP2=$this->direction=null;
		$this->link=null;
		$this->identCount=0;
	}

	private function getTimeString($str) {
		$vals=array();
		if (preg_match('/(\d+:\d+:\d+)/', $str, $vals))
			return $vals[1];

		return $str;
	}

	private static function getTimeFromString($str, $throw=true) {
		$ar=array();
		if (!preg_match('/(\d+):(\d+):(\d+)/', $str, $ar)) {
			if($throw)
				throw new Exception("Wrong time: $str");
			return false;
		}

		$dt=new DateTime();
		$dt->setTimestamp(0);
		$dt->setTime($ar[1], $ar[2], $ar[3]);
		return $dt->getTimestamp();
	}

	function dateStart_timeString() {
		return $this->getTimeString($this->dateStart);
	}

	function dateEnd_timeString() {
		return $this->getTimeString($this->dateEnd);
	}

	function dateStart_time() {
		return self::getTimeFromString($this->dateStart);
	}

	function dateEnd_time() {
		if(isset($this->dateEnd))
			return self::getTimeFromString($this->dateEnd);
		return null;
	}

	function SesionLenghtString() {
		if(isset($this->dateEnd)) {
			$l=$this->dateEnd_time()-$this->dateStart_time();
			$dt=new DateTime('now', new DateTimeZone("GMT+0"));
			$dt->setTimestamp($l);
			return $dt->format("H:i:s");
		}
		return null;
	}

/*
	function date_array() {
		return date_parse_from_format("d.F.Y:H:i:s O", $this->date_str);
	}

*/

}

class MpdLog
{

	var $lines;
	var $line;
	var $eof;

	function __construct($file_name) {
		$this->readfile($file_name);
	}

	function readfile($file_name, $throw=true)
	{
		$bz2=preg_match("/.bz2$/", $file_name);
		if($bz2)
			$f = bzopen($file_name, "r");
		else
			$f = fopen($file_name, "r");

		if (!$f) {
			if($throw) {
				throw new Exception("Error open $file_name");
			}
			else {
				return false;
			}
		}
		while(true) {
			$line=fgets($f);
			if($line===FALSE) {
				break;
			}
			else {
				$this->lines[]=$line;
			}
		}
		if($bz2)
			bzclose($f);
		else
			fclose ($f);

		$this->eof=false;
		$this->line=0;
		return true; // return true on sucsess
	}

	/**
	  * @return MpdLog_Data
	*/
	function read(MpdLog_Data $item=null)
	{
	if($this->eof) {
		return false;
	}

	$line_next=false;
	$r=false;
	$link=false;
	while(true) {
		if ($this->line>=count($this->lines)) {
			break;
		}
		$line=$this->lines[$this->line++];

		$ar=array();
		if(!$r && preg_match("/^([^0-9]+\d+ [^ ]+) [^:]+: PPTP: Incoming control connection from ([0-9.]+) ([0-9]+) to ([0-9.]+) ([0-9]+)$/", $line, $ar)) {
			$line_next=$this->line;

			if(!isset($item))
				$r=new MpdLog_Data();
			else
				$r=$item;

			$r->reset();
			$r->dateStart=$ar[1];
			$r->ip=$ar[2];
			$r->port=$ar[3];
		}
		if($r) {
			if($link) {
				if(!isset($r->user) && preg_match('/^[^0-9]+\d+ [^ ]+ [^:]+: \[L-'.$r->link.'\]   Name: "([^"]+)"/',$line, $ar)) {
					$r->user=$ar[1];
				}
				if($r->identCount<2 && preg_match('/^[^0-9]+\d+ [^ ]+ [^:]+: \[L-'.$r->link.'\]   MESG: (.+)/',$line, $ar)) {
					if(strlen($r->ident))
						$r->ident.=", ";
					$r->ident.=$ar[1];
					$r->identCount++;
				}
				if(!isset($r->tunIP1) && preg_match('/^[^0-9]+\d+ [^ ]+ [^:]+: \[B-'.$r->link.'\]   ([0-9.]+) -> ([0-9.]+)/',$line, $ar)) {
					$r->tunIP1=$ar[1];
					$r->tunIP2=$ar[2];
					$link=false;
				}
				/*if(!isset($r->direction) && preg_match('/^[^0-9]+\d+ [^ ]+ [^:]+: \[L-'.$r->link.'\] Link: origination is remote/',$line, $ar)) {
					$r->direction=">";
				}*/
			}
			elseif(preg_match("/^[^0-9]+\d+ [^ ]+ [^:]+: pptp([0-9]+): attached to connection with $r->ip $r->port/", $line, $ar)) {
				$link=$ar[1]+1;
				$r->link=$link;
			}
			if(preg_match("/^([^0-9]+\d+ [^ ]+) [^:]+: pptp[0-9]+: killing connection with $r->ip $r->port$/", $line, $ar)) {
				$r->dateEnd=$ar[1];
				break;
			}
		}
	}

	if($r===false) {
		$this->eof=true;
		return false;
	}

	if(!isset($r->direction))
		$r->direction=">";

	if($line_next!==FALSE)
		$this->line=$line_next;
	return $r;

	}
}

class DnsResolver {
	private $arCache;
	private $ExpireTime;
	private static $Instance;

	function __construct() {
		$this->arCache=array();
		$this->ExpireTime=time()-30*DAY;
		$this->Load();
	}

	function __destruct() {
		$this->Save();
	}

	static function GetHostName($ip) {
		if(!is_object(self::$Instance)) {
			self::$Instance=new DnsResolver();
		}
		$me=self::$Instance;
		if(array_key_exists($ip, $me->arCache)) {
			return $me->arCache[$ip]["Value"];
		}

		$r=gethostbyaddr($ip);
		$me->arCache[$ip]=array("Value"=>$r, "Time"=>time());
		return $r;
	}

	private function Save() {
		$file=__DIR__."/cache/DnsResolver.csv";
		if (!file_exists(dirname($file))) {
			mkdir(dirname($file), 0700);
		}
		$fp = fopen($file, 'w');

		foreach ($this->arCache as $key=>$arValue) {
			fputcsv($fp, array($key,$arValue['Value'],$arValue['Time']),";");
		}

		fclose($fp);
	}

	private function Load() {
		$file=__DIR__."/cache/DnsResolver.csv";
		if (file_exists($file) && ($handle = fopen($file, "r")) !== FALSE) {
			$line=1;
			while (($data = fgetcsv($handle, 0, ";")) !== FALSE) {
				if(count($data)!=3) {
					$this->arCache=array();
					SendError("DnsResolver->Load() error","Error load DnsResolver cache line: $line unexpected fields count: ".implode(";", $data));
					return flase;
				}
				$time=intval($data[2]);
				if($time>$this->ExpireTime) {
					$this->arCache[$data[0]]=array('Value'=>$data[1], "Time"=>$time);
				}
				$line++;
			}
			fclose($handle);
		}
		return true;
	}
}

?>
