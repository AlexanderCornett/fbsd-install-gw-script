<?php

/*
30.10.2013
    лог сквида без авторизации (ident=ip) и даты в логе в формате dd\mm\yyyy hh:mm:ss
*/


include("/usr/local/scripts/sql.inc.php");


// open a connection to the database server
$constr = "host=".SQLHost." dbname=".database." user=".SQLUser." password=".SQLPass;
$connection = pg_connect($constr);

if (!$connection)
{
    die("Could not open connection to database server");
}

// open log
$log=fopen(logfile,"a") or die("Cant open log file");

// scanning inbound
$d=dir(squidlogpath);

while (false!==($entry=$d->read()))
{
//    if (eregi("^access",$entry))		// deprecated
    if (preg_match("/^access/",$entry))
    {
	fwrite($log,date("d.m.Y H:i:s")." Open ".squidlogpath.$entry.".\n");
	$handle=fopen(squidlogpath.$entry,"r");
	if ($handle)
	{
	    $readed=0; $inserted=0;
	    while (!feof($handle))
	    {
		$buffer = fgets($handle);
		if (strlen($buffer)>0)
		{
		    $readed++;
		    $buffers = preg_split("/\s+/",$buffer);

//		    if (!eregi("^TCP_DENIED/407",$buffers[3]))		// deprecated
		    if (!preg_match("/^TCP_DENIED\/407/",$buffers[3]))
		    {
			$inserted++;
			
//			$dt=strftime("%Y-%m-%d %H:%M:%S",$buffers[0]);
			$dt=substr($buffers[0],6,4)."-".
			    substr($buffers[0],3,2)."-".
			    substr($buffers[0],0,2)." ".
			    $buffers[1];
			
//			$ident = urldecode($buffers[7]);
//			$ident = iconv('koi8-r','utf-8',$ident);
//			$type = iconv('koi8-r','utf-8',preg_replace("/\'/","",substr($buffers[9],1,46)));
//			$link = iconv('koi8-r','utf-8',preg_replace("/\'/","",$buffers[6]));

//			$ident = urldecode($buffers[8]);
//			$ident = iconv('koi8-r','utf-8',$ident);
			$ident = $buffers[3];
			$type = iconv('koi8-r','utf-8',preg_replace("/\'/","",substr($buffers[10],1,46)));
			$link = iconv('koi8-r','utf-8',preg_replace("/\'/","",$buffers[7]));
			$metod = iconv('koi8-r','utf-8',preg_replace("/\'/","",substr($buffers[6],0,10)));

			
//			echo "Link=".$buffers[6]."->".$link."\n";

//			echo "\n";

//			$query = "insert into squid (dt,duration,ip,result,bytes,metod,link,ident,trans,type)
//				values ('".$dt."',".$buffers[1].",'".$buffers[2]."','".$buffers[3]."',".$buffers[4].",'".
//				$buffers[5]."','".$link."','".$ident."','".$buffers[8]."','".$type."')";


			$query = "insert into squid (dt,duration,ip,result,bytes,metod,link,ident,trans,type)
				values ('".$dt."',".$buffers[2].",'".$buffers[3]."','".$buffers[4]."',".$buffers[5].",'".
				$metod."','".$link."','".$ident."','".$buffers[9]."','".$type."')";

//			echo "\n".$query."\n";
//			exit;


			if (!pg_query($connection,$query))
			{
				fwrite($log,date("d.m.Y H:i:s")." Fatal error ms_query!!! Abort! \n\n");
				fwrite($log,$query."\n\n");
				fclose($log);
				fclose($handle);
				pg_close($connection);
				echo "\n".$query."\n";
				exit;
                       }		     
                    }
		}
	    }
	    fwrite($log,date("d.m.Y H:i:s")." Readed ".$readed." records, inserted ".$inserted." records.\n");
	    fwrite($log,date("d.m.Y H:i:s")." Close ".squidlogpath.$entry.".\n");
	    fclose($handle);
	
	
	    fwrite($log,date("d.m.Y H:i:s")." Move an gzip ".squidlogpath.$entry." into ".squidlogpath."saved\n");
	    rename(squidlogpath.$entry,squidlogpath."saved/".$entry);
	    $cmd = "gzip ".squidlogpath."saved/".$entry;
	    exec($cmd);
	    
	}  //feof
	else
	    fwrite($log,date("d.m.Y H:i:s")." ERROR: Can't open ".squidlogpath.$entry.".\n");
    }
}


// close database connection
$d->close();
pg_close($connection);
fwrite($log,date("d.m.Y H:i:s")." End.\n\n");
fclose($log);
exit;
?>