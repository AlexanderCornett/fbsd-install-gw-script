#!/bin/sh

#postgresql
/usr/local/etc/rc.d/postgresql initdb

cp /var/postgresql.conf /usr/local/pgsql/data/postgresql.conf


#add access
echo "host all all %MAIN_PC%/32 trust" >> /usr/local/pgsql/data/pg_hba.conf
echo "listen_addresses = 'localhost,%MAIN_GW_ADDR%'" >> /usr/local/pgsql/data/postgresql.conf

/usr/local/etc/rc.d/postgresql start

createuser -U pgsql pguser
createdb -U pgsql corall -O pguser
psql -U pgsql -d corall -f /var/corall.sql

#squid and remove cron
/usr/local/sbin/squid -z
rm /var/cron/tabs/root
sleep 10
sysrc squid_enable=YES

pkg check -r

reboot


