--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.3
-- Dumped by pg_dump version 9.6.2

SET statement_timeout = 0;
SET lock_timeout = 0;
-- SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

--
-- Name: getlink(character varying); Type: FUNCTION; Schema: public; Owner: pguser
--

CREATE FUNCTION getlink(_link character varying) RETURNS character varying
    LANGUAGE plpgsql
    AS $$declare myLink varchar;
declare i integer;
begin
 myLink=regexp_replace(_link,'http://','');

 i=position('/' in myLink);
 if (i<>0) then 
   myLink=substr(myLink,1,i-1);
 end if;

 i=position(':' in myLink);
 if (i<>0) then 
  myLink=substr(myLink,1,i-1);
 end if;

 return myLink;
end;$$;


ALTER FUNCTION public.getlink(_link character varying) OWNER TO pguser;

--
-- Name: sptopsite(timestamp without time zone, timestamp without time zone); Type: FUNCTION; Schema: public; Owner: pguser
--

CREATE FUNCTION sptopsite(_dt1 timestamp without time zone, _dt2 timestamp without time zone) RETURNS refcursor
    LANGUAGE plpgsql
    AS $$
declare ref refcursor;
begin
open ref for select Sum(bytes) as total,getlink(link) as site 
from squid
where dt between _dt1 and _dt2
group by site
order by total desc;
return ref;
end;$$;


ALTER FUNCTION public.sptopsite(_dt1 timestamp without time zone, _dt2 timestamp without time zone) OWNER TO pguser;

--
-- Name: sptopsize(timestamp without time zone, timestamp without time zone); Type: FUNCTION; Schema: public; Owner: pguser
--

CREATE FUNCTION sptopsize(_dt1 timestamp without time zone, _dt2 timestamp without time zone) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
declare mysize bigint;
begin
select Sum(bytes) 
from squid
into mysize
where dt between _dt1 and _dt2;

return mysize;
end;$$;


ALTER FUNCTION public.sptopsize(_dt1 timestamp without time zone, _dt2 timestamp without time zone) OWNER TO pguser;

--
-- Name: sptopuser(timestamp without time zone, timestamp without time zone); Type: FUNCTION; Schema: public; Owner: pguser
--

CREATE FUNCTION sptopuser(_dt1 timestamp without time zone, _dt2 timestamp without time zone) RETURNS refcursor
    LANGUAGE plpgsql
    AS $$
declare ref refcursor;
begin
open ref for 
 select ident, Sum(bytes) as total 
 from squid
 where (dt between _dt1 and _dt2)
 group by ident
 order by total desc;

return ref;
end;$$;


ALTER FUNCTION public.sptopuser(_dt1 timestamp without time zone, _dt2 timestamp without time zone) OWNER TO pguser;

--
-- Name: sptopusersite(timestamp without time zone, timestamp without time zone, character varying); Type: FUNCTION; Schema: public; Owner: pguser
--

CREATE FUNCTION sptopusersite(_dt1 timestamp without time zone, _dt2 timestamp without time zone, _user character varying) RETURNS refcursor
    LANGUAGE plpgsql
    AS $$
declare ref refcursor;
begin
open ref for 
 select Sum(bytes) as total, getlink(link) as site
 from squid
 where (dt between _dt1 and _dt2) and ident=_user
 group by site
 order by total desc;

return ref;
end;$$;


ALTER FUNCTION public.sptopusersite(_dt1 timestamp without time zone, _dt2 timestamp without time zone, _user character varying) OWNER TO pguser;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: squid; Type: TABLE; Schema: public; Owner: pguser
--

CREATE TABLE squid (
    dt timestamp without time zone,
    duration bigint,
    ip character varying(15),
    result character varying(50),
    bytes bigint,
    metod character varying(10),
    link text,
    ident character varying(50),
    trans character varying(100),
    type character varying(46)
);


ALTER TABLE squid OWNER TO pguser;

--
-- Name: sqdt; Type: INDEX; Schema: public; Owner: pguser
--

CREATE INDEX sqdt ON squid USING btree (dt);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON SCHEMA public TO pgsql;


--
-- PostgreSQL database dump complete
--

